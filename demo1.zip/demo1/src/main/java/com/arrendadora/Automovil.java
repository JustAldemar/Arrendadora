package com.arrendadora;

public class Automovil {
    private String marca;
    private String modelo;
    private String tipoAuto;
    private int cantSillas;
    private int precio;
    private int year;
    private String estado;

    public Automovil(String marca, String modelo, String tipoAuto, int cantSillas, int precio, int year, String estado) {
        this.marca = marca;
        this.modelo = modelo;
        this.tipoAuto = tipoAuto;
        this.cantSillas = cantSillas;
        this.precio = precio;
        this.year = year;
        this.estado = estado;
    }
    // Getters y setters
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipoAuto() {
        return tipoAuto;
    }

    public void setTipoAuto(String tipoAuto) {
        this.tipoAuto = tipoAuto;
    }

    public int getCantSillas() {
        return cantSillas;
    }

    public void setCantSillas(int cantSillas) {
        this.cantSillas = cantSillas;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }


    // toString()

    @Override
    public String toString() {
        return "automovil{" +
                "marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", tipoAuto='" + tipoAuto + '\'' +
                ", cantSillas=" + cantSillas +
                ", precio=$" + precio +
                ", year=" + year +
                ", estado='" + estado + '\'' +
                '}';
    }
}
