package com.arrendadora;

public class bus extends Automovil {
    public bus(String marca, String modelo, String tipoAuto, int cantSillas, int precio, int year, String estado) {
        super(marca, modelo, tipoAuto, cantSillas, precio, year, estado);
    }
}
