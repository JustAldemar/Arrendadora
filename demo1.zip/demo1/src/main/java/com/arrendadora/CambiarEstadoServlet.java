package com.arrendadora;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "cambiarEstadoServlet", value = "/cambiar-estado")
public class CambiarEstadoServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String modelo = request.getParameter("modelo");

        // Retrieve the list of vehicles from the servlet context
        List<Automovil> vehiculos = (List<Automovil>) getServletContext().getAttribute("vehiculos");

        // Find and update the state of the vehicle
        for (Automovil vehiculo : vehiculos) {
            if (vehiculo.getModelo().equals(modelo)) {
                vehiculo.setEstado("Dañado".equals(vehiculo.getEstado()) ? "Disponible" : "Dañado");
                break;
            }
        }

        // Update the servlet context
        getServletContext().setAttribute("vehiculos", vehiculos);

        // Redirect back to the arrendadoraFRD.jsp
        response.sendRedirect("automoviles-cargados");
    }
}