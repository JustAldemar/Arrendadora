package com.arrendadora;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@WebServlet(name = "automovilesCargadosServlet", value = "/automoviles-cargados")
public class AutomovilesCargados extends HttpServlet {
    List<Automovil> vehiculos = new ArrayList<>();

    @Override
    public void init() throws ServletException {
        super.init();
        // Initialize the list of vehicles and set it in the servlet context
        if (vehiculos.isEmpty()) {
            vehiculos.add(new sedan("Toyota", "Corolla", "Sedán", 5, 200, 2022, "Disponible"));
            vehiculos.add(new bus("Mercedes", "Sprinter", "Bus", 20, 450, 2023, "Disponible"));
            vehiculos.add(new motocicleta("Yamaha", "MT-07", "Motocicleta", 2, 70, 2021, "Disponible"));
            vehiculos.add(new pick_up("Ford", "F-150", "Pick-Up", 5, 300, 2020, "Disponible"));
            vehiculos.add(new camioneta("Chevrolet", "Suburban", "Camioneta", 7, 550, 2024, "Disponible"));
        }
        getServletContext().setAttribute("vehiculos", vehiculos);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve filter parameters
        String marca = request.getParameter("marca");
        String modelo = request.getParameter("modelo");
        String color = request.getParameter("color");
        String asientosStr = request.getParameter("asientos");
        String keyword = request.getParameter("keyword");

        // Filter out vehicles with state "Dañado"
        List<Automovil> vehiculosDisponibles = vehiculos.stream()
                .filter(vehiculo -> !"Dañado".equals(vehiculo.getEstado()))
                .filter(vehiculo -> (marca == null || marca.isEmpty() || vehiculo.getMarca().equalsIgnoreCase(marca)))
                .filter(vehiculo -> (modelo == null || modelo.isEmpty() || vehiculo.getModelo().equalsIgnoreCase(modelo)))
                .filter(vehiculo -> (asientosStr == null || asientosStr.isEmpty() || vehiculo.getCantSillas() == Integer.parseInt(asientosStr)))
                .filter(vehiculo -> (keyword == null || keyword.isEmpty() || vehiculo.getMarca().contains(keyword) || vehiculo.getModelo().contains(keyword) || vehiculo.getTipoAuto().contains(keyword)))
                .collect(Collectors.toList());

        // Pass the list of available vehicles to the JSP
        request.setAttribute("vehiculos", vehiculosDisponibles);

        // Determine which JSP to forward to based on a query parameter
        String page = request.getParameter("page");
        if ("eliminar".equals(page)) {
            request.getRequestDispatcher("eliminarAuto.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("arrendadoraFRD.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String marca = request.getParameter("marca");
        String modelo = request.getParameter("modelo");
        String tipoAuto = request.getParameter("tipoAuto");
        int asientos = Integer.parseInt(request.getParameter("asientos"));
        int precio = Integer.parseInt(request.getParameter("precio"));
        int anho = Integer.parseInt(request.getParameter("año"));
        String estado = request.getParameter("estado");

        Automovil nuevoVehiculo = new Automovil(marca, modelo, tipoAuto, asientos, precio, anho, estado);

        // Add the new vehicle to the list
        vehiculos.add(nuevoVehiculo);

        // Redirect back to the get method to show the updated list
        response.sendRedirect("automoviles-cargados");
    }
}