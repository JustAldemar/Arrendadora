package com.arrendadora;

public class camioneta extends Automovil {
    public camioneta(String marca, String modelo, String tipoAuto, int cantSillas, int precio, int year, String estado) {
        super(marca, modelo, tipoAuto, cantSillas, precio, year, estado);
    }

}
