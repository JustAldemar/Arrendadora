package com.arrendadora;

public class pick_up extends Automovil {
    public pick_up(String marca, String modelo, String tipoAuto, int cantSillas, int precio, int year, String estado) {
        super(marca, modelo, tipoAuto, cantSillas, precio, year, estado);
    }

}
