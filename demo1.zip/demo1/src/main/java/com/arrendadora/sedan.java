package com.arrendadora;

public class sedan extends Automovil {
    public sedan(String marca, String modelo, String tipoAuto, int cantSillas, int precio, int year, String estado) {
        super(marca, modelo, tipoAuto, cantSillas, precio, year, estado);
    }


}
