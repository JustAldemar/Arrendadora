package com.arrendadora;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "editarAutoServlet", value = "/editar-auto")
public class EditarAutoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String modelo = request.getParameter("modelo");

        // Retrieve the list of vehicles from the servlet context
        List<Automovil> vehiculos = (List<Automovil>) getServletContext().getAttribute("vehiculos");

        // Find the vehicle to edit
        Automovil vehiculoAEditar = vehiculos.stream()
                .filter(vehiculo -> vehiculo.getModelo().equals(modelo))
                .findFirst()
                .orElse(null);

        // Forward the vehicle to editarAuto.jsp
        request.setAttribute("vehiculo", vehiculoAEditar);
        request.getRequestDispatcher("editarAuto.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get form data
        String modeloOriginal = request.getParameter("modeloOriginal");
        String marca = request.getParameter("marca");
        String modelo = request.getParameter("modelo");
        String tipoAuto = request.getParameter("tipoAuto");
        int asientos = Integer.parseInt(request.getParameter("asientos"));
        int precio = Integer.parseInt(request.getParameter("precio"));
        int anho = Integer.parseInt(request.getParameter("año"));
        String estado = request.getParameter("estado");

        // Retrieve the list of vehicles from the servlet context
        List<Automovil> vehiculos = (List<Automovil>) getServletContext().getAttribute("vehiculos");

        // Find and update the vehicle
        for (Automovil vehiculo : vehiculos) {
            if (vehiculo.getModelo().equals(modeloOriginal)) {
                vehiculo.setMarca(marca);
                vehiculo.setModelo(modelo);
                vehiculo.setTipoAuto(tipoAuto);
                vehiculo.setCantSillas(asientos);
                vehiculo.setPrecio(precio);
                vehiculo.setYear(anho);
                vehiculo.setEstado(estado);
                break;
            }
        }

        // Update the servlet context
        getServletContext().setAttribute("vehiculos", vehiculos);

        // Redirect back to the eliminarAuto.jsp
        response.sendRedirect("modificar-auto");
    }
}