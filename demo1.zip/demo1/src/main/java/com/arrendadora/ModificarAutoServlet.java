package com.arrendadora;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "modificarAutoServlet", value = "/modificar-auto")
public class ModificarAutoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve the list of vehicles from the servlet context
        List<Automovil> vehiculos = (List<Automovil>) getServletContext().getAttribute("vehiculos");

        // Forward the request to eliminarAuto.jsp
        request.setAttribute("vehiculos", vehiculos);
        request.getRequestDispatcher("eliminarAuto.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String modelo = request.getParameter("modelo");

        if ("delete".equals(action)) {
            // Retrieve the list of vehicles from the servlet context
            List<Automovil> vehiculos = (List<Automovil>) getServletContext().getAttribute("vehiculos");

            // Remove the vehicle with the specified model
            vehiculos.removeIf(vehiculo -> vehiculo.getModelo().equals(modelo));

            // Update the servlet context
            getServletContext().setAttribute("vehiculos", vehiculos);
        }

        // Redirect back to the eliminarAuto.jsp
        response.sendRedirect("modificar-auto");
    }
}